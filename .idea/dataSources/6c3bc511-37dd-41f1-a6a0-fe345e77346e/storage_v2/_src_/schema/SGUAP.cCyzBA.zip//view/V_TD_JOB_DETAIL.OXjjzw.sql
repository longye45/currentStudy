create view V_TD_JOB_DETAIL as
  select jd.sched_name
         ,jd.job_name
         ,jd.job_group
         ,jd.description
         ,jd.job_class_name
         ,jd.is_durable
         ,jd.is_nonconcurrent
         ,jd.is_update_data
         ,jd.requests_recovery
         ,jde.log_strategy
         ,jde.job_earlywarning
         ,jde.job_timeout
         ,jde.job_alias
         ,jde.application_id
         ,jde.application_name
         ,jde.job_create_date
         ,jde.job_update_date
         ,jde.group_index
         ,jde.execute_count
         ,jde.is_cutpoint_redo
         ,jeeh.handle_type
         ,jeeh.attemp_times
         ,jeeh.attemp_interval
         ,g.group_name as job_group_name
         ,jde.global_param
         ,f_td_getjobstate(jd.sched_name,jd.job_name,jd.job_group) job_state
         ,dd.data_name as job_state_name
         ,jde.cnt_failed
         ,jde.cnt_succeeding
    from T_TD_EXT_JOB_DTL jde
    left join T_TD_JOB_DETAILS jd on jd.job_name=jde.job_name
    left join T_TD_EXT_JOB_EXHDL jeeh on jd.job_name=jeeh.job_name
    left join T_TD_EXT_GROUP g on jd.job_group = g.groupid
    left join t_td_ext_data_dict dd on ( dd.data_type = 'JobState' and dd.data_key = f_td_getjobstate(jd.sched_name,jd.job_name,jd.job_group) )
/

