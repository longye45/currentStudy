create view V_TD_EXT_EXEC_CPNT as
  select ec."COMPONENT_ID",ec."COMPONENT_NAME",ec."COMPONENT_GROUP",ec."COMPONENT_TYPE",ec."URI",ec."BEAN_ID",ec."DESCRIPTION",ec."CREATE_DATE",ec."COMPONENT_PARAM",ec."GROUP_INDEX",ec."SCRIPTED_TEXT",g.group_name as component_group_name,dd.data_name as component_type_name,g.application_id,g.application_name
       ,cs.component_state, cs.checkin_interval, cs.checkin_time
    from t_td_ext_exec_cpnt ec
    left join t_td_ext_group g on ec.component_group = g.groupid
    left join t_td_ext_data_dict dd on (dd.data_type='ComponentType' and ec.component_type = dd.data_key)
    left join t_td_ext_cpnt_state cs on cs.component_id = ec.component_id
/

