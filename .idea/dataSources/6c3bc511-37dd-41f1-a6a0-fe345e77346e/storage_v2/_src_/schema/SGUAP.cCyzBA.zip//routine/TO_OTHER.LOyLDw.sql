create function       to_other(str1 in varchar2) return varchar2 as
  str varchar2(100);
begin
  str := (case str1
           when '智利' then
              '中南美其它国家'
            when '委内瑞拉' then
              '中南美其它国家'
            when '哥伦比亚' then
              '中南美其它国家'
            when '厄瓜多尔' then
              '中南美其它国家'
            when '秘鲁' then
               '中南美其它国家'
            when '特立尼达和多巴哥' then
               '中南美其它国家'
            when '玻利维亚' then
               '中南美其它国家'
            when '牙买加' then
               '中南美其它国家'
            when '哥斯达黎加'then
               '中南美其它国家'
            when '古巴'then
               '中南美其它国家'
            when '多米尼加'then
                '中南美其它国家'
            when '萨尔瓦多'then
                '中南美其它国家'
            when '危地马拉'then
               '中南美其它国家'
            when '海地'then
              '中南美其它国家'
            when '洪都拉斯'then
              '中南美其它国家'
            when '尼加拉瓜'then
               '中南美其它国家'
            when '巴拿马'then
                '中南美其它国家'
            when '巴拉圭'then
               '中南美其它国家'
            when '乌拉圭'then
                '中南美其它国家'
            when '安提瓜和巴布达'then
                '中南美其它国家'
            when '阿鲁巴'then
                '中南美其它国家'
            when '巴哈马'then
               '中南美其它国家'
            when '巴巴多斯'then
                '中南美其它国家'
            when '伯利兹'then
                '中南美其它国家'
            when '百慕大群岛'then
               '中南美其它国家'
            when '因属维京群岛'then
                '中南美其它国家'
            when '开曼群岛'then
               '中南美其它国家'
            when '多米尼克'then
                '中南美其它国家'
            when '福克兰群岛'then
               '中南美其它国家'
            when '法属圭亚那'then
                '中南美其它国家'
            when '格林纳达'then
                '中南美其它国家'
            when '瓜德罗普岛'then
                '中南美其它国家'
            when '圭亚那'then
                '中南美其它国家'
             when '马提尼克'then
                '中南美'
            when '蒙特塞拉特岛'then
                '中南美其它国家'
            when '波多黎各'then
                '中南美其它国家'
            when '圣基茨和尼维斯'then
                '中南美其它国家'
            when '圣露西亚'then
                '中南美其它国家'
            when '苏里南'then
               '中南美其它国家'
            when '圣马丁岛'then
               '中南美其它国家'
             when '以色列'then
                '亚太地区其它国家'
            when '新西兰'then
                 '亚太地区其它国家'
            when '孟加拉'then
                '亚太地区其它国家'
            when '文莱'then
                '亚太地区其它国家'
            when '柬埔寨'then
                '亚太地区其它国家'
            when '中国台湾'then
                '亚太地区其它国家'
            when '马来西亚'then
                '亚太地区其它国家'
            when '蒙古'then
                '亚太地区其它国家'
            when '朝鲜'then
                '亚太地区其它国家'
            when '缅甸'then
                '亚太地区其它国家'
            when '尼泊尔'then
                '亚太地区其它国家'
            when '巴基斯坦'then
                '亚太地区其它国家'
            when '菲律宾'then
                 '亚太地区其它国家'
            when '新加坡'then
                 '亚太地区其它国家'
            when '斯里兰卡'then
                '亚太地区其它国家'
            when '泰国'then
                '亚太地区其它国家'
            when '越南'then
                '亚太地区其它国家'
            when '阿富汗'then
                '亚太地区其它国家'
            when '不丹'then
                '亚太地区其它国家'
            when '库克群岛'then
                '亚太地区其它国家'
            when '东帝汶'then
                '亚太地区其它国家'
            when '裴济'then
                '亚太地区其它国家'
            when '法属波利尼西亚'then
                 '亚太地区其它国家'
            when '基里巴斯'then
                '亚太地区其它国家'
            when '老挝'then
                '亚太地区其它国家'
            when '马尔代夫'then
                '亚太地区其它国家'
            when '新喀里多尼亚'then
                '亚太地区其它国家'
            when '帕劳群岛'then
                '亚太地区其它国家'
            when '巴布亚新几内亚'then
                '亚太地区其它国家'
            when '所罗门群岛'then
                '亚太地区其它国家'
            when '萨摩亚'then
                '亚太地区其它国家'
            when '汤家'then
                '亚太地区其它国家'
            when '瓦努阿图'then
                '亚太地区其它国家'
             when '哈萨克斯坦'then
                '欧洲其它国家'
             when '乌克兰'then
                '欧洲其它国家'
            when '格鲁吉亚'then
                '欧洲其它国家'
             when '尼日利亚'then
                '非洲其它国家'
            when '阿尔及利亚'then
                '非洲其它国家'
            when '安哥拉'then
                '非洲其它国家'
             when '突尼斯'then
                '非洲其它国家'
            when '几内亚'then
                '非洲其它国家'
              when '乌干达'then
                '非洲其它国家'
            when '津巴布韦'then
                '非洲其它国家'
            when '佛得角'then
                '非洲其它国家'
            when '中非'then
                '非洲其它国家'
            when '吉布提'then
                '非洲其它国家'
             when '毛里求斯'then
                 '非洲其它国家'
            when '利比里亚'then
                '非洲其它国家'
             when '比利时'then
                '欧洲其它国家'
            when '捷克'then
                '欧洲其它国家'
             when '丹麦'then
               '欧洲其它国家'
            when '爱沙尼亚'then
               '欧洲其它国家'
            when '芬兰'then
               '欧洲其它国家'
            when '希腊'then
               '欧洲其它国家'
            when '匈牙利'then
               '欧洲其它国家'
            when '爱尔兰'then
               '欧洲其它国家'
            when '卢森堡'then
               '欧洲其它国家'
           else
            str1
         end
  );
    return str;
end;

/

