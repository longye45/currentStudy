create procedure       addTemplateXh Authid Current_User as
  orginfo      SYS_REFCURSOR; --组织信息
  xhchar       GES_REPORT_COUNTRY_TEMPLATE.xh%type; --最终序号
  rownums      varchar2(32); --组织的序号
  tempnum      varchar2(32); --组织下属国家的序号
  country_id   GES_REPORT_COUNTRY_TEMPLATE.country_id%type;
  country_name GES_REPORT_COUNTRY_TEMPLATE.country_name%type;
  countryinfo  SYS_REFCURSOR; --国家信息
  updateid     varchar2(32);
  updatesql    varchar2(4000);
begin
  open orginfo for 'select lpad(to_char(rownum), 2, 0) num,country_id,id from (select  t.country_id, t.id from GES_REPORT_COUNTRY_TEMPLATE t where org_id is null and report_id = (select id from ges_report_template where create_time = (select max(create_time) from ges_report_template)) order by t.time asc)';
  LOOP
    -- 游标向前.
    FETCH orginfo
      INTO rownums, country_id, country_name;
    -- 无数据的情况下，退出循环.
    EXIT WHEN orginfo%NOTFOUND;
    xhchar := rownums||'00';
    EXECUTE IMMEDIATE 'update GES_REPORT_COUNTRY_TEMPLATE set xh = '''||xhchar||''' where id = '''||country_name||'''';
    open countryinfo for 'select t.id,replace(lpad(to_char(rownum),2),'' '',''0'') from GES_REPORT_COUNTRY_TEMPLATE t where org_id = ''' || country_id || ''' and report_id = (select id from ges_report_template where create_time = (select max(create_time) from ges_report_template)) order by t.create_time asc';
    loop
      -- 游标向前.
      FETCH countryinfo
        INTO updateid, tempnum;
      -- 无数据的情况下，退出循环.
      EXIT WHEN countryinfo%NOTFOUND;
      xhchar    := rownums || tempnum;
      updatesql := 'update GES_REPORT_COUNTRY_TEMPLATE set xh = ''' ||
                   xhchar || ''' where id = ''' || updateid || '''';
      dbms_output.put_line(updatesql);
      EXECUTE IMMEDIATE updatesql;
    end loop;
  END LOOP;
  end addTemplateXh;

/

