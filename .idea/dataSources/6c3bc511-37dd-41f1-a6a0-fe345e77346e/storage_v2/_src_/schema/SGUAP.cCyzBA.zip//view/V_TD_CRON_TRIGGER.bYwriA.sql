create view V_TD_CRON_TRIGGER as
  SELECT t."SCHED_NAME",t."TRIGGER_NAME",t."TRIGGER_GROUP",t."JOB_NAME",t."JOB_GROUP",t."DESCRIPTION",t."NEXT_FIRE_TIME",t."PREV_FIRE_TIME",t."PRIORITY",t."TRIGGER_STATE",t."TRIGGER_TYPE",t."START_TIME",t."END_TIME",t."CALENDAR_NAME",t."MISFIRE_INSTR",t."JOB_DATA",
       ct.cron_expression,
       ct.time_zone_id,
       dd.data_name as trigger_state_name,
       ec.calendar_alias
  FROM t_td_triggers t
  LEFT JOIN t_td_cron_triggers ct ON t.trigger_name = ct.trigger_name
  LEFT JOIN t_td_ext_data_dict dd ON (dd.data_type = 'TriggerState' and
                                     t.trigger_state = dd.data_key)
  LEFT JOIN t_td_ext_calender ec ON t.calendar_name = ec.calendar_name
  WHERE ct.cron_expression IS NOT NULL
/

