create view V_GES_4E_WORLD_TOP as
  select time,country_id,index_id,unit,value,product_id,dimension_id,mappingid
    from ges_4e_data_economy
    union all
     select time,country_id,index_id,unit,value,product_id,dimension_id,mappingid
    from ges_4e_data_electric
    union all
     select time,country_id,index_id,unit,value,product_id,dimension_id,mappingid
    from ges_4e_data_energy
    union all
     select time,country_id,index_id,unit,value,product_id,null,mappingid
    from ges_4e_data_environment
     union all
     select time,tcountry_id as country_id,index_id,unit,value,product_id,null,mappingid
    from ges_4e_data1_economy
     union all
     select time,tcountry_id as country_id,index_id,unit,value,product_id,null,mappingid
    from ges_4e_data1_electric
     union all
     select time,tcountry_id as country_id,index_id,unit,value,product_id,null,mappingid
    from ges_4e_data1_energy
     union all
     select time,tcountry_id as country_id,index_id,unit,value,product_id,null,mappingid
    from ges_4e_data1_environment
/

