create function       test_divide_by_zero(expression varchar2) return number is
v_RESULT number;
v_sql varchar2(100);
begin
    -- 拼动态 SQL.
  v_Sql := 'SELECT ' || expression || '  FROM dual';
  -- 执行动态 SQL， 并将结果存储到变量中.
  EXECUTE IMMEDIATE ( v_Sql )   INTO v_RESULT ;
  -- 返回.
    return v_RESULT;
exception when ZERO_DIVIDE then
    return  -1;
when others then  return  null;
end;

/

