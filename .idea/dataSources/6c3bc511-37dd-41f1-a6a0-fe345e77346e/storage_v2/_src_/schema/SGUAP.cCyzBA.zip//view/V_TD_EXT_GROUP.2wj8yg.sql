create view V_TD_EXT_GROUP as
  select GROUPID,GROUP_NAME,APPLICATION_ID,APPLICATION_NAME,GROUP_TYPE,CREATE_DATE,CREATE_PEOPLE,PARENT_ID,
         to_number(group_index) as group_index
    from T_TD_EXT_GROUP
/

