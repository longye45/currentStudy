create view GES_UN_COUNTRY as
  select id, englishname country, chinesename country_name from ges_4e_country
/

