create view V_TD_EXT_LSNR as
  select t."LSNR_ID",t."LSNR_NAME",t."LSNR_ASSOCIATION",t."LSNR_APPID",t."LSNRT_CODE",t."LSNRT_NAME",t."LSNRT_TYPE",t."LSNRT_CLASS",t."LSNR_ISGLOBAL",t."LSNR_ISLOADING",t."LSNR_OPERATOR",t."LSNR_OPERATETIME",t1.job_group from t_td_ext_lsnr t
left join t_td_ext_job_dtl t1 on t.lsnr_association=t1.job_name
/

