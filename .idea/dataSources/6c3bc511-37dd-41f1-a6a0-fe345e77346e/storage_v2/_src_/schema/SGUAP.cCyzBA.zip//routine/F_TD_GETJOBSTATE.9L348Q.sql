create function       f_td_getjobstate(schedName varchar2,
                                                jobName   varchar2,
                                                jobGroup  varchar2)
  return int is
  v_state varchar2(20);
  v_cnt   int;
begin
  v_state:=1;
  /*
   0:未部署,1:运行中,2:停止,3:部分运行,4:异常
  */
  select count(1)
    into v_cnt
    from T_TD_TRIGGERS t
   where t.sched_name = schedName
     and t.job_name = jobName
     and t.job_group = jobGroup
     and t.trigger_group<>'DEFAULT' and t.trigger_state<>'COMPLETE';
  if v_cnt=0 then
     v_state := 0;
     return v_state;
  end if;

  select count(1)
    into v_cnt
    from T_TD_TRIGGERS t
   where t.sched_name = schedName
     and t.job_name = jobName
     and t.job_group = jobGroup
     and t.trigger_group<>'DEFAULT'
     and t.trigger_state='ERROR';
  if v_cnt>0 then
     v_state := 4;
     return v_state;
  end if;

  select count(1)
    into v_cnt
    from T_TD_TRIGGERS t
   where t.sched_name = schedName
     and t.job_name = jobName
     and t.job_group = jobGroup
     and t.trigger_group<>'DEFAULT'
     and t.trigger_state in ('PAUSED','PAUSED_BLOCKED');
  if v_cnt>0 then
    select count(1)
    into v_cnt
    from T_TD_TRIGGERS t
   where t.sched_name = schedName
     and t.job_name = jobName
     and t.job_group = jobGroup
     and t.trigger_group<>'DEFAULT'
     and t.trigger_state<>'PAUSED' and t.trigger_state<>'ERROR' and t.trigger_state<>'PAUSED_BLOCKED' and t.trigger_state<>'COMPLETE';
    if v_cnt>0 then
     v_state := 3;
    else
     v_state := 2;
    end if;
  end if;

  return v_state;

end f_td_getjobstate;

/

