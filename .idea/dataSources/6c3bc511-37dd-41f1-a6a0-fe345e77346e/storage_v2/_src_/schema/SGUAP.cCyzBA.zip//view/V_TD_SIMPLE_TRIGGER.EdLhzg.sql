create view V_TD_SIMPLE_TRIGGER as
  SELECT t."SCHED_NAME",t."TRIGGER_NAME",t."TRIGGER_GROUP",t."JOB_NAME",t."JOB_GROUP",t."DESCRIPTION",t."NEXT_FIRE_TIME",t."PREV_FIRE_TIME",t."PRIORITY",t."TRIGGER_STATE",t."TRIGGER_TYPE",t."START_TIME",t."END_TIME",t."CALENDAR_NAME",t."MISFIRE_INSTR",t."JOB_DATA",
       ct.repeat_count,
       to_char(ct.repeat_interval) repeat_interval,
       ct.times_triggered,
       dd.data_name as trigger_state_name,
       ec.calendar_alias
  FROM t_td_triggers t
  LEFT JOIN t_td_simple_triggers ct ON t.trigger_name = ct.trigger_name
  LEFT JOIN t_td_ext_data_dict dd ON (dd.data_type = 'TriggerState' and
                                     t.trigger_state = dd.data_key)
  LEFT JOIN t_td_ext_calender ec ON t.calendar_name = ec.calendar_name
  WHERE ct.repeat_count IS NOT NULL and ct.repeat_interval IS NOT NULL and t.trigger_group <>'RECOVERING_JOBS'and t.trigger_group <>'DEFAULT'
/

