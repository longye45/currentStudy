create PROCEDURE ges_user_session_proc  IS
 BEGIN
   DELETE FROM GES_SESSION_NUM where  TO_NUMBER(sysdate - create_time)  * 24 * 60 * 60 > 10;
   COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('Exception happened,data was rollback');
     ROLLBACK;
 END;
/

