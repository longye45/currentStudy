create function       to_eu(str1 in varchar2) return varchar2 as
  str varchar2(100);
begin
  str := (case str1
          when '德国'then
                '欧盟'
            when '法国'then
                 '欧盟'
            when '英国'then
                '欧盟'
            when '意大利'then
                '欧盟'
            when '西班牙'then
                '欧盟'
            when '奥地利'then
                 '欧盟'
            when '比利时'then
                 '欧盟'
            when '捷克'then
                 '欧盟'
             when '丹麦'then
                 '欧盟'
            when '爱沙尼亚'then
                 '欧盟'
            when '芬兰'then
                '欧盟'
            when '希腊'then
                 '欧盟'
            when '匈牙利'then
                 '欧盟'
            when '爱尔兰'then
                '欧盟'
            when '卢森堡'then
                '欧盟'
            when '荷兰'then
                '欧盟'
            when '波兰'then
                '欧盟'
            when '葡萄牙'then
                '欧盟'
            when '斯洛伐克'then
                '欧盟'
            when '斯洛文尼亚'then
                 '欧盟'
            when '瑞典'then
                '欧盟'
            when '冰岛'then
                '欧盟'
            when '挪威'then
               '欧盟'
            when '瑞士'then
                '欧盟'
             when '土耳其'then
                '欧盟'
            when '阿尔巴尼亚'then
                 '欧盟'
            when '波斯尼亚和黑塞哥维亚'then
                '欧盟'
            when '保加利亚'then
                '欧盟'
            when '塞浦路斯'then
                '欧盟'
            when '克罗地亚'then
                '欧盟'
           else
            str1
         end
  );
    return str;
end;

/

