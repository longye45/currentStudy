create procedure       createfullindex Authid Current_User as
  indextables        SYS_REFCURSOR;
  sqlresult          varchar2(4000);
  source_id          ges_data_sources.id%type;
  source_chinesename ges_data_sources.SOURCE_CHINESENAME%type;
  SOURCE_TABLE_NAME  ges_data_sources.SOURCE_TABLE_NAME%type;
  SOURCE_TYPE        ges_data_sources.SOURCE_TYPE%type;
begin
  open indextables for 'select id, SOURCE_CHINESENAME,SOURCE_TABLE_NAME,SOURCE_TYPE from ges_data_sources where SOURCE_TABLE_NAME is not null';
  sqlresult := 'create or replace view v_ges_fullpathindex as ';
  LOOP
    -- 游标向前.
    FETCH indextables
      INTO source_id,source_chinesename, SOURCE_TABLE_NAME, SOURCE_TYPE;
    -- 无数据的情况下，退出循环.
    EXIT WHEN indextables%NOTFOUND;
    if SOURCE_TYPE = 1 then
      sqlresult := sqlresult ||
                   'select id id,decode(chinesename,null,englishname,chinesename) name,''' ||
                   source_chinesename || '->''||' ||
                   'full_path indexpath, '''||source_id||''' sourceid from ' || SOURCE_TABLE_NAME ||
                   ' union all ';
    elsif SOURCE_TYPE = 0 then
      sqlresult := sqlresult ||
                   'select id id,decode(chinesename,null,englishname,chinesename) name,''' ||
                   source_chinesename || '->''||' ||
                   'full_path indexpath, '''||source_id||''' sourceid from ' || SOURCE_TABLE_NAME ||
                   ' union all ';
    end if;
  END LOOP;
  sqlresult := sqlresult || ' select '''' id,'''' name,'''' full_path,'''' sourceid  from dual';
  dbms_output.put_line(sqlresult);
  EXECUTE IMMEDIATE sqlresult;


end createfullindex;

/

