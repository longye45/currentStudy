create view V_GES_4E_UNIT as
  select distinct unit
  from ges_4e_data_economy
union
select distinct unit
  from ges_4e_data_electric
union
select distinct unit
  from ges_4e_data_energy
union
select distinct unit
  from ges_4e_data_environment
union
select distinct unit
  from ges_4e_data1_economy
union
select distinct unit
  from ges_4e_data1_electric
union
select distinct unit
  from ges_4e_data1_energy
union
select distinct unit from ges_4e_data1_environment
/

