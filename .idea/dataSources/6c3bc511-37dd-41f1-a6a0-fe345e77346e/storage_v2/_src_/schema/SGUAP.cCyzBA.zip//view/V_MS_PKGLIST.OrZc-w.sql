create view V_MS_PKGLIST as
  (select j.inst_id, u.user_name,inst_name, tmpl_id, inst_ctime
  from T_ms_jobinst j, T_ms_userjobinst u, T_ms_job_up ju
 where u.inst_id = j.inst_id
   and u.inst_id=ju.pkg_id(+)
   and u.user_name=ju.user_name(+)
   and (ju.pkg_up_state IS NULL OR ju.pkg_up_state!='C')
   and j.inst_c_state = 'A') order by inst_ctime desc
/

