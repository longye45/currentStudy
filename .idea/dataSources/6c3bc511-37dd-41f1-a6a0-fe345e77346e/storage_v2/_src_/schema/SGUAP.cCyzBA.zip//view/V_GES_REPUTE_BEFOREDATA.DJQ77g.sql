create view V_GES_REPUTE_BEFOREDATA as
  select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'BP' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_bp_data1 t, ges_4e_country c, ges_bp_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'UN' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_un_data t, ges_4e_country c, ges_un_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'WB' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_wb_data t, ges_4e_country c, ges_wb_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'Globaldata' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_global_data t, ges_4e_country c, ges_global_index i
 where c.id = t.country_id
   and i.id = t.index_id and t.time not like 'C%'
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'Bloomberg' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_bloomberg_data t, ges_4e_country c, ges_bloomberg_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'IEA' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_iea_data t, ges_4e_country c, ges_iea_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'IAEA' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_IAEA_data t, ges_4e_country c, ges_IAEA_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       '风险指标' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_countryrisk_data t, ges_4e_country c, ges_countryrisk_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       '国网能源研究院报告' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_report_data t, ges_4e_country c, ges_report_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'EIA' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_EIA_data t, ges_4e_country c, ges_EIA_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'CES' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_CES_data t, ges_4e_country c, ges_CES_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'GACC' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_GACC_data t, ges_4e_country c, ges_GACC_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'NBS' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_NBS_data t, ges_4e_country c, ges_NBS_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'CEC' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_CEC_data t, ges_4e_country c, ges_CEC_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'WIND' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_WIND_data t, ges_4e_country c, ges_WIND_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'EUES' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_EUES_data t, ges_4e_country c, ges_EUES_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'Value500' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_v5_data t, ges_4e_country c, ges_v5_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'IMF' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_IMF_data t, ges_4e_country c, ges_IMF_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'IRENA' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_IRENA_data t, ges_4e_country c, ges_IRENA_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'BMI' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_risk_data t, ges_4e_country c, ges_risk_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'REN21' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_REN21_data1 t, ges_4e_country c, ges_REN21_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       'WEC' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_WEC_data t, ges_4e_country c, ges_WEC_index i
 where c.id = t.country_id
   and i.id = t.index_id
union
select t.id as id,
       c.chinesename as country,
       t.time as year,
       t.unit as unit,
       t.value as value,
       '一库三中心' as sources,
       decode(i.chinesename, null, i.englishname, i.chinesename) as index_name,
       t.create_time as create_time
  from ges_ykszx_data t, ges_4e_country c, ges_ykszx_index i
 where c.id = t.country_id
   and i.id = t.index_id
/

